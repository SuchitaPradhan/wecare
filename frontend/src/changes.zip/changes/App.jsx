import { Routes, Route } from "react-router-dom";
import Home from "./pages/Home";
import Signin from "./pages/Signin";
import Signup from "./pages/Signup";
import Booking from "./pages/Booking";
import DoctorDashboard from "./pages/DoctorDashboard";
import Patientdashboard from "./pages/Patientdashboard";
import AdminDashboard from "./pages/Admindashboard";
import Doctors from "./pages/Doctors";

function AppRoutes() {
  return (
    <Routes>
      <Route path="/" element={<Home />} />
      <Route path="/signin" element={<Signin />} />
      <Route path="/signup" element={<Signup />} />
      <Route path="/booking" element={<Booking />} />
      <Route path="/DoctorDashboard" element={<DoctorDashboard />} />
      <Route path="/Patientdashboard" element={<Patientdashboard />} />
      <Route path="/AdminDashboard" element={<AdminDashboard />} />
      <Route path="*" element={<div>Page Not Found</div>} />
      <Route path="/doctors" element={<Doctors />} />

    </Routes>
  );
}

export default function App() {
  return <AppRoutes />;
}

